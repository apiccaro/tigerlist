import addRem from "../../modAddRem.js";

    await addRem();
